#Armada Scraper
Scrapes data from listing pages on [Armada](https://www.armadarealestate.com/inventory.aspx?propertyId=248786-sale)